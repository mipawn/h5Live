// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import fast from 'fastclick'
import swiper from 'vue-awesome-swiper'
import './assets/css/reset.css'
import 'swiper/dist/css/swiper.css'
import 'animate.css'
import './assets/css/iconfont.css'
import JSBridge from './SZJSBridge'
Vue.use(JSBridge)
Vue.config.productionTip = false
Vue.use(swiper)
fast.attach(document.body)
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>',
  render: h => h(App)
})
