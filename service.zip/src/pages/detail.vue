<template>
  <div class="detail">
    <transition enter-active-class="animated slideInDown" leave-active-class="animated slideOutUp">
      <div class="top" v-show="istop">
        <b><i class="iconfont icon-angle-double-up"></i></b>
        <span>下拉进入 —
          <span v-if="movieShow">影像{{region}}</span>
          <span v-if="!movieShow">图说改革</span>
        </span>
      </div>
    </transition>
    <div class="container" @scroll="scrollTo" @touchmove="toNext" @touchstart="addEvent">
      <header>
        <transition
          enter-active-class="animated flipInY"
          leave-active-class="animated fadeOut">
          <img v-show="show1" :src="'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/region/' + region +'.png'" alt="" class="region">
        </transition>
        <transition
          enter-active-class="animated flipInY"
          leave-active-class="animated fadeOut">
          <img v-show="show2" src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/detailTitle1.png" alt="" class="title">
        </transition>
        <img src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/return.png" @click="goBack" alt="" class="return">
      </header>
      <section>
        <transition
          enter-active-class="animated flipInY"
          leave-active-class="animated fadeOut">
          <img v-show="show3" :src="'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/third/'+ region +'.png'" alt="">
        </transition>
      </section>
      <footer>
        <dl @click="toDetail('bigbang')" class="rotate">
          <dd>
            <img src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/third/2.png" alt="">
          </dd>
          <dt>改革大事记</dt>
        </dl>
        <dl @click="toDetail('photo')" class="rotate" v-if="photoShow">
          <dd>
            <img src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/third/3.png" alt="">
          </dd>
          <dt>图说改革</dt>
        </dl>
        <dl @click="toDetail('movie')" class="rotate" v-if="movieShow">
          <dd>
            <img src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/third/4.png" alt="">
          </dd>
          <dt>影像{{region}}</dt>
        </dl>
      </footer>
      <div class="logo">
        <img src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/home/homeFooter.png" alt="" class="btmImg">
      </div>
    </div>
    <div class="icons">
      <i :class="'iconfont icon-music' + (audioPlay ? ' shake' : '')" @click="toggleMusic"></i>
    </div>
    <div class="share" @click="share" v-if="canShare">
      <span>分享</span>
    </div>
    <div class="watched">
      <span>阅读量</span>
      {{watched || ''}}
    </div>
    <transition enter-active-class="animated slideInUp" leave-active-class="animated slideOutDown">
      <div class="btm" v-show="isbottom">
        <b><i class="iconfont icon-angle-double-up"></i></b>
        <span>上滑进入 — <span>改革大事记</span> </span>
      </div>
    </transition>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  naem: 'detail',
  props: {
    audioPlay: Boolean,
    watched: Number
  },
  data () {
    return {
      show1: false,
      show2: false,
      show3: false,
      isbottom: true,
      istop: true,
      next: false,
      screenY: 0,
      scrollTop: 0,
      region: '进化',
      id: 13,
      movieShow: true,
      photoShow: true
    }
  },
  methods: {
    toDetail (path) {
      this.$router.push({
        path,
        query: {
          region: this.$route.query.region,
          dir: 1,
          id: this.id
        }
      })
    },
    goBack () {
      this.$router.push({
        path: '/selector'
      })
    },
    toggleMusic () {
      this.$emit('music')
    },
    scrollTo (e) {
      this.scrollTop = e.target.scrollTop
      this.isbottom = this.scrollTop === this.delta
      this.istop = this.scrollTop === 0
    },
    toNext (e) {
      if (!this.screenY) return
      if (this.isbottom && this.screenY && (e.targetTouches[0].screenY < this.screenY - 60)) {
        this.$router.replace({
          path: 'bigbang',
          query: {
            id: this.id,
            dir: 1,
            region: this.$route.query.region
          }
        })
      }
      if (this.istop && this.screenY && (e.targetTouches[0].screenY > this.screenY)) {
        e.preventDefault()
        if (e.targetTouches[0].screenY > this.screenY + 60) {
          this.$router.replace({
            path: this.movieShow ? 'movie' : 'photo',
            query: {
              id: this.id,
              dir: 0,
              region: this.$route.query.region
            }
          })
        }
      }
    },
    addEvent (e) {
      if (this.isbottom || this.istop) {
        this.screenY = e.targetTouches[0].screenY
      } else {
        this.screenY = 0
      }
    },
    getData () {
      let url = 'http://item.xianghunet.com/index/reform/content'
      let data = new FormData()
      data.append('id', this.id)
      axios.post(url, data)
        .then(res => {
          let info = res.data.res
          window.streetInfo = {
            id: info.id || 1,
            content: info.content || '',
            img_url: info.img_url || [],
            video_url: info.video_url || ''
          }
        })
    },
    share () {
      if (window.PalauAPI) {
        window.PalauAPI.share('all', '我骄傲，我是' + this.region + '人，勇立潮头，' + this.region + '改革开放40年全景图', '40年了，这些大事发生在萧然大地上，影响了你我，今天我们一起回顾，也一起展望未来。',
          location.href, 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/regoShare.png')
      }
    }
  },
  mounted () {
    this.region = this.$route.query.region
    this.id = +this.$route.query.id
    this.movieShow = !(this.id === 1 || this.id === 4 || this.id === 6 || this.id === 8 || this.id === 9)
    this.photoShow = !(this.id === 2)
    this.getData()
    this.show1 = true
    setTimeout(() => {
      this.show2 = true
    }, 600)
    setTimeout(() => {
      this.show3 = true
    }, 1200)
    // window.shareTitle = '勇立潮头，' + this.region + '改革开放40年全景图'
    // window.shareLink = location.href
    // window.shareDesc = '40年了，这些大事发生在萧然大地上，影响了你我，今天我们一起回顾，也一起展望未来。'
    // if (window.wx) {
    //   window.wx.ready(() => {
    //     // alert(window.shareLink)
    //     document.getElementById('music').play()
    //     window.wx.onMenuShareTimeline({
    //       title: '勇立潮头，' + this.region + '改革开放40年全景图',
    //       link: window.shareLink,
    //       imgUrl: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/regoShare.png',
    //       success: function () {
    //       }
    //     })
    //     window.wx.onMenuShareAppMessage({
    //       title: '勇立潮头，' + this.region + '改革开放40年全景图',
    //       desc: '40年了，这些大事发生在萧然大地上，影响了你我，今天我们一起回顾，也一起展望未来。',
    //       link: window.shareLink,
    //       imgUrl: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/regoShare.png',
    //       type: '',
    //       dataUrl: '',
    //       success: function () {
    //       }
    //     })
    //   })
    // }
  },
  computed: {
    canShare () {
      return window.canShare
    }
  }
}
</script>

<style lang="stylus" scoped>
@keyframes rotate
  0%
    transform rotatey(90deg)
  100%
    transform  rotatey(0)
.rotate
  transform rotatey(90deg)
  animation rotate 1s
  animation-fill-mode forwards
.detail
  overflow auto
  .container
    height 100%
    display flex
    flex-direction column
    header
      padding 1rem 1rem 0
      position relative
      height 3.3rem
      box-sizing border-box
      text-align center
      img
        height 1.2rem
      .title
        margin-left 1rem
        height 1rem
        margin-top .1rem
      .return
        position absolute
        left 0
        top 2.4rem
        width 1.8rem
    section
      padding 0 .8rem
      flex 1
      overflow hidden
      img
        width 100%
        height 100%
        object-fit contain
    footer
      display flex
      justify-content space-around
      padding .2rem
      margin-bottom 1.2rem
      .rotate
        transform rotatey(90deg)
        animation rotate 1s
        animation-fill-mode forwards
      dl
        position relative
        flex 1
        max-width 2.2rem
        margin 0 15px
        background rgba(0,0,0,.4)
        border 1px solid rgba(255,255,255,.6)
        border-radius .1rem
        padding-bottom .2rem
        &:nth-child(1)
          animation-delay .25s
        &:nth-child(2)
          animation-delay .5s
        &:nth-child(3)
          animation-delay .75s
        &:nth-child(4)
          animation-delay 1s
        &:before
          content ''
          position absolute
          height 0
          bottom -.4rem
          left 25%
          right 25%
          box-shadow 0 0 30px 5px rgba(0,0,0,.8)
        dd
          padding .3rem
          height 1rem
          text-align center
          img
            max-width 100%
            max-height 100%
        dt
          font-size .24rem
          color #ffffff
          text-align center
    .logo
      position fixed
      bottom .2rem
      left 0
      right 0
      text-align left
      img
        width 3rem
        margin 0 .3rem
  .icons
    position absolute
    right .3rem
    top .3rem
    color #fff
    i
      font-size .44rem
      padding .12rem
      display inline-block
      box-sizing border-box
      border 1px solid #ffffff
      border-radius 50%
      background rgba(255,255,255,.4)
    .icon-music
      color #999
      position relative
      &:after
        content ''
        border-top 1px solid #fff
        position absolute
        width 100%
        top 50%
        left 0
        transform rotate(40deg)
    .icon-share
      margin-right .2rem
      color #3bf
    .shake
      animation rock 3s linear infinite
      color #000
      &:after
        display none
  .share
    position fixed
    top 1.2rem
    right 0
    border-radius .4rem 0 0 .4rem
    color #ffffff
    background #129ade
    font-size .32rem
    padding .2rem .1rem .2rem .2rem
    text-align center
    box-shadow 2px 2px 5px #888
    .parti
      font-size 12px
      .iconfont
        font-size 14px
  .watched
    position fixed
    left .3rem
    top .6rem
    color #fff
  .top, .btm
    position fixed
    top 0
    left 0
    right 0
    color #fff
    line-height 3
    text-align center
    animation-duration .3s
    z-index 2
    pointer-events none
    background linear-gradient(to top, transparent, rgba(255,255,255,.5))
    i
      display inline-block
      animation pop 1s infinite cubic-bezier(.25,.0,.75,1)
  .btm
    background linear-gradient(to bottom, transparent, rgba(255,255,255,.5))
    top auto
    bottom 0
    text-align right
    padding-right .6rem
    b
      display inline-block
      transform rotateZ(180deg)
@keyframes pop
  0%
    transform translateY(-5px)
  50%
    transform translateY(5px)
  100%
    transform translateY(-5px)
@keyframes swing
  0%
    background-position 0% 0%
  50%
    background-position 40% 0%
  100%
    background-position 0% 0%
</style>
