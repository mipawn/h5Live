<template>
  <div class="speech">
    <transition enter-active-class="animated slideInDown" leave-active-class="animated slideOutUp">
      <div class="top" v-show="istop">
        <b><i class="iconfont icon-angle-double-up"></i></b>
        <span>下拉进入 — <span>影像进化</span> </span>
      </div>
    </transition>
    <div class="container" ref="container" @scroll="scrollTo" @touchmove="toNext" @touchstart="addEvent">
      <header>
        <img src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/region/进化镇.png')" alt="" class="region"><br>
        <img src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/speech.png')" alt="" class="title"><br>
        <img class="return" src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/return.png')" @click="goBack" alt="">
      </header>
      <section>
        <div class="video">
          <video src=""></video>
        </div>
        <div :class="'content'" ref="content">
          <div class="text">
            <p>1979年6月6日《浙江日报》报道，萧山县第一、第二农垦场进行飞机直播水稻作业。</p>
            <p>1979年12月25日，全县农村促富会议召开。</p>
            <p>1986年冬，15万民工在钱塘河口段筑堤围涂5.2万亩。时至今日，许许多多的祖辈、父辈，对“围垦”的记忆难忘终生！感谢你们当年辛勤的付出！</p>
            <p>1988年1月1日，萧山撤县设市。</p>
            <p>1992年，6月11日，萧山新火车站投入使用。如今新的火车南站焕然一新！一起期待它投入使用！</p>
            <p>1993年5月，国务院批准设立萧山经济技术开发区。</p>
            <p>2000年12月28日，萧山机场首航成功，机场高速通车。</p>
            <p>2002年1月23日，萧山剧院工程通过验收。该工程占地面积5200平方米，总建筑面积11985平方米，是萧山区的标志性建筑物之一。</p>
            <p>2002年5月1日，浙江（中国）花木城开城。</p>
            <p>2012年11月24日，杭州地铁1号线正式通车，萧山迈入地铁时代。</p>
            <p>2016年5月3日，“省门第一路”——萧山机场公路高架主线正式通车。</p>
            <p>2016年9月4日，G20 杭州峰会在萧山开幕。</p>
            <p>2017年11月8日，首届萧山人大会在国博中心召开。</p>
            <p>2018年2月12日，亚运村落户萧山，萧山进入“亚运时间”。</p>
          </div>
        </div>
      </section>
    </div>
    <transition enter-active-class="animated slideInUp" leave-active-class="animated slideOutDown">
      <div class="btm" v-show="isbottom">
        <b><i class="iconfont icon-angle-double-up"></i></b>
        <span>上滑进入 — <span>改革大事记</span> </span>
      </div>
    </transition>
  </div>
</template>

<script>
export default {
  name: 'speech',
  data () {
    return {
      isbottom: false,
      istop: true,
      next: false,
      screenY: 0,
      scrollTop: 0
    }
  },
  methods: {
    goBack () {
      this.$router.go(-1)
    },
    scrollTo (e) {
      // this.$refs.container.style.backgroundPositionY = (e.target.scrollTop / this.delta * 100) + '%'
      // this.$refs.container.style.backgroundPositionX = (e.target.scrollTop / this.delta * 100) + '%'
      this.scrollTop = e.target.scrollTop
      this.isbottom = this.scrollTop === this.delta
      this.istop = this.scrollTop === 0
    },
    toNext (e) {
      if (!this.screenY) return
      if (this.isbottom && this.screenY && (e.targetTouches[0].screenY < this.screenY - 60)) {
        this.$router.replace({
          path: 'bigbang',
          query: {
            dir: 1
          }
        })
      }
      if (this.istop && this.screenY && (e.targetTouches[0].screenY > this.screenY)) {
        e.preventDefault()
        if (e.targetTouches[0].screenY > this.screenY + 60) {
          this.$router.replace({
            path: 'movie',
            query: {
              dir: 0
            }
          })
        }
      }
    },
    addEvent (e) {
      if (this.isbottom || this.istop) {
        this.screenY = e.targetTouches[0].screenY
      } else {
        this.screenY = 0
      }
    }
  },
  computed: {
    delta () {
      return this.$refs.container.scrollHeight - this.$refs.container.clientHeight
    }
  }
}
</script>

<style lang="stylus" scoped>
.speech
  .container
    min-height 170vw
    height 100%
    background url('~https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/speechbg.png')repeat 0% 0%
    background-size 120% 120%
    animation swing 16s infinite
    overflow auto
    header
      padding-top 1rem
      padding-left .8rem
      position relative
      text-align center
      .region
        height 1.2rem
        padding-right 1.6rem
      .title
        height .8rem
      .return
        position absolute
        left 0
        top 1.6rem
        width 1.8rem
    section
      padding .6rem .3rem 1rem
      display flex
      flex-direction column
      .video
        padding-top 60%
        position sticky
        top 0
        video
          position absolute
          width 100%
          height 100%
          top 0
          background #000
      .content
        line-height 1.5
        flex 1
        // background linear-gradient(to top, #8de, #fff)
        background rgba(255,255,255,.8)
        margin-top .4rem
        border 2px solid #000
        padding .4rem
        overflow hidden
        transition .3s
        p
          margin-bottom .2rem
  .top, .btm
    position fixed
    top 0
    left 0
    right 0
    color #fff
    line-height 3
    text-align center
    animation-duration .3s
    z-index 2
    background linear-gradient(to top, transparent, rgba(255,255,255,.5))
    i
      display inline-block
      animation pop 1s infinite cubic-bezier(.25,.0,.75,1)
  .btm
    background linear-gradient(to bottom, transparent, rgba(255,255,255,.5))
    top auto
    bottom 0
    b
      display inline-block
      transform rotateZ(180deg)
@keyframes pop
  0%
    transform translateY(-5px)
  50%
    transform translateY(5px)
  100%
    transform translateY(-5px)
@keyframes swing
  0%
    background-position 0% 0%
  50%
    background-position 100% 100%
  100%
    background-position 0% 0%
</style>
