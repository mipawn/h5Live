<template>
  <div class="bigbang">
    <div class="container" ref="container" @scroll="scrollTo">
      <header>
        <img class="title" src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/alltitle1.png" alt="">
        <img class="return" src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/return.png" @click="goBack" alt="">
      </header>
      <section>
        <div :class="'content'" ref="content">
          <!-- eslint-disable -->
          <div class="text">
            <div class="item" v-for="(item, index) of bigBang" :key="index">
              <p class="title">{{item.title}}</p>
              <div class="video">
                <video :poster="item.poster" @play="videoPlay" @pause="videoPause"
                  :src="item.video" controls loop ref="allVideo"></video>
              </div>
              <p>{{item.content}}</p>
            </div>
            <p></p>
          </div>
        </div>
        <div class="logo">
          <img
            src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/home/homeFooter.png" alt="" class="btmImg">
        </div>
      </section>
      <div class="icons">
        <i :class="'iconfont icon-music' + (audioPlay ? ' shake' : '')" @click="toggleMusic"></i>
      </div>
      <div class="share" @click="share" v-if="canShare">
        <span>分享</span>
      </div>
      <div class="watched">
        <span>阅读量</span>
        {{watched || ''}}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'bigbang',
  props: {
    audioPlay: Boolean,
    watched: Number
  },
  data () {
    return {
      bigBang: [
        {
          title: '1、促富大会开启萧山改革开放大幕',
          content: '1979年12月25日，中共萧山县委召开全县农村促富大会，号召全县人民树立敢于做“富”字文章的思想，大力营造“先富光荣”的社会舆论。大会彻底消除了人们头脑中长期以来把“富”字当作资本主义的“左”的精神枷锁，广辟门路，谋富致富，解开了人们渴望致富的“紧箍咒”，充分动员全社会都来为萧山的发展出谋划策，鼓劲加油。会议隆重表彰了一批曾遭批判的“冒富”对象为劳动模范，从而彻底消除了人们“谈富色变”的心理阴影，树立了敢于“想富”、勇于“致富”的思想观念，从而开启了萧山改革发展的大幕。',
          video: 'http://v.cztvcloud.com/video/xhw/vod/2018/12/24/9d25bd36cfab4461b549625b5404519c/9d25bd36cfab4461b549625b5404519c_h264_800k_mp4.mp4',
          poster: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/ten/1.jpg'
        },
        {
          title: '2、撤县设市和撤市设区促使萧山华丽转身',
          content: '1988年1月1日，国务院批准萧山正式撤县设市，开始从小农经济模式迅速迈入工业化、城市化发展的轨道，城市意识、都市理念逐渐形成，城市规划和建设日趋都市风范。2001年3月25日，萧山又撤市设区，融入大杭州发展格局，使萧山形成了新的区位优势，城市化概念进一步增强，城乡一体化进程进一步加快。两次具有里程碑意义的脱胎换骨的华丽转身，使萧山从农业经济迅速向城市化迈进，萧山从此成为华夏版图上一方投资热土、创业乐园、休闲名都、幸福宝地。',
          video: 'http://v.cztvcloud.com/video/xhw/vod/2018/12/24/8ffc6e0466e94f1caebe29f1c82e0886/8ffc6e0466e94f1caebe29f1c82e0886_h264_800k_mp4.mp4',
          poster: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/ten/2.jpg'
        },
        {
          title: '3、萧山乡镇企业基本完成转制',
          content: '1996年，城镇集体企业、乡镇集体企业转制工作基本完成，初步建立了以“产权清晰、权责明确、政企分开、管理科学”为目的的现代企业管理制度。从1992年开始，实现了乡镇企业异军突起的萧山人，着手对企业产权制度改革进行创新和探索。《深化企业改革转换经营机制的实施意见》随后出台，明确了企业转制目标。到1996年，全区已有97.36%的乡镇集体工业企业完成转制。从1997年到2000年，进行了国有、二轻、农垦、商业、粮食、供销、贸易等系统企业的改革攻坚，机制创新促使企业活力进一步增强，也为萧山经济的持续发展打下了坚实的基础。',
          video: 'http://v.cztvcloud.com/video/xhw/vod/2018/12/24/da37831b0222486fbaba5366b24c7f50/da37831b0222486fbaba5366b24c7f50_h264_800k_mp4.mp4',
          poster: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/ten/3.jpg'
        },
        {
          title: '4、萧山工业冲千亿',
          content: '2002年，萧山“工业立区、工业兴区”战略实现新跨越，工业产值总量冲破千亿大关，占杭州市工业总量的三分之一。工业冲千亿，不仅体现了萧山经济发展在质的提高过程中确保了量的扩张，同时也体现了萧山人民“敢与强的比,敢同勇的争,敢向高的攀,敢跟快的赛”的精神，更成为凝聚全区干部群众齐心协力发展经济，再上台阶，敢于领先的共同奋斗目标。同时千亿目标的实现，经济的快速发展，为解决社会民生问题打下了扎实基础。工业冲千亿表明了萧山的工业发展已经迈出新的发展步伐。',
          video: 'http://v.cztvcloud.com/video/xhw/vod/2018/12/24/7ee7b2641f584b34ba2849522d1aeaf1/7ee7b2641f584b34ba2849522d1aeaf1_h264_800k_mp4.mp4',
          poster: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/ten/4.jpg'
        },
        {
          title: '5、萧山经济技术开发区设立',
          content: '1990年5月，萧山经济技术开发区开始创建，1993年5月，经国务院批准为国家级经济技术开发区，区域面积9.2平方公里，铸就了萧山招商引资主平台，这是萧山经济和社会发展史上一个新的里程碑。2015年3月，萧山科技城整体划归开发区管理，在益农镇设立新产业园区。目前，开发区总规划面积已经拓展到150平方公里（包括水域面积），从最初集中于市北区块，扩展到了市北、桥南、科技城、益农拓展区、宁围（除钱江世纪城）和新街。开发区已拥有规上工业企业174家，限上服务业企业170家，工业产值超亿元企业90家，国家级高新技术企业102家，上市企业15家，世界500强企业12家，形成了机械制造、电子电器、医药食品、建材家具、新材料新能源、数字经济等支柱产业。',
          video: 'http://v.cztvcloud.com/video/xhw/vod/2018/12/24/1266cad2ea054810b3fc56b5ac39b6e0/1266cad2ea054810b3fc56b5ac39b6e0_h264_800k_mp4.mp4',
          poster: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/ten/5.jpg'
        },
        {
          title: '6、鲁冠球成为中国民营企业家杰出典范',
          content: '1990年4月，美国《时代周刊》以《中国农民的希望》为题，发表对鲁冠球的专访。1991年5月，鲁冠球成为美国《新闻周刊》封面人物，轰动世界。萧山农民鲁冠球以4000元一个铁匠铺起家，经过几十年艰苦创业，使企业最终发展成国内最大的民营企业之一。2015年10月15日，《2015胡润百富榜》发布，鲁冠球及其家族以650亿元位列第十，财富比2014年净增65%。他在全国率先提出“花钱买不管”的理念，从而成为我国企业史上产权意识最早苏醒的农民企业家之一。鲁冠球被国内外舆论誉为民营企业家中的“常青树”，成为中国民营企业家的杰出典范。',
          video: 'http://v.cztvcloud.com/video/xhw/vod/2018/12/24/fd778f3498bb40c089c4649ab2d8a6cb/fd778f3498bb40c089c4649ab2d8a6cb_h264_800k_mp4.mp4',
          poster: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/ten/6.jpg'
        },
        {
          title: '7、杭州萧山国际机场建成',
          content: '1997年7月，杭州萧山国际机场正式动工建设，2000年12月建成通航。机场的建成与投入使用，成为萧山对外开放的重要窗口，标志着萧山立体交通网络基本形成，拉开了空港经济发展序幕。2009年8月，杭州空港经济区成立，园区规划面积68.6平方公里，成为浙江省打造“两港物流圈”（杭州空港、宁波海港）战略的重要组成部分。2007年11月，机场二期工程正式开工建设，2012年12月建成投运。2016年，机场圆满完成了G20杭州峰会航空运输保障任务,同年启动三期扩建工程，总投资规模在270亿元以上，主要工程计划在2022年亚运会前建成投运。',
          video: 'http://v.cztvcloud.com/video/xhw/vod/2018/12/24/72a985543d62417e9b20691f9586e1cb/72a985543d62417e9b20691f9586e1cb_h264_800k_mp4.mp4',
          poster: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/ten/7.jpg'
        },
        {
          title: '8、圆梦湘湖全面完成',
          content: '2016年9月30日，湘湖三期开园，至此，湘湖基本恢复古湘湖“葫芦状”的形态。早在1995年9月12日，浙江省政府批准建立了湘湖旅游度假区。2003年，萧山区委、区政府做出了“圆梦湘湖，还湖于民”的重大决策。2006年4月，湘湖区块一期工程初步建成并对外开放。2011年9月14日，湘湖二期开园。2015年10月，湘湖被列为全国首批国家级旅游度假区，2017年12月，世界旅游联盟总部落户湘湖。如今湘湖已经成为萧山人最具魅力的休闲场所，省内外具有较高知名度的旅游度假区，并成功创建成为首批国家级旅游度假区，成为杭州旅游的一张金名片。',
          video: 'http://v.cztvcloud.com/video/xhw/vod/2018/12/24/2552b8673dd448e38a0c323462398fcd/2552b8673dd448e38a0c323462398fcd_h264_800k_mp4.mp4',
          poster: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/ten/8.jpg'
        },
        {
          title: '9、G20峰会成功举办',
          content: '2016年9月4日—5日, 第十一次二十国集团领导人杭州峰会（G20杭州峰会），在地处萧山的杭州国际博览中心隆重举行。国家主席习近平主持会议并宣布大会开幕。G20杭州峰会确定“构建创新、活力、联动、包容的世界经济”为主题，倡导“创新驱动型增长”，为世界经济注入新的动力，对促进世界经济增长、完善全球经济治理发挥重要作用。这次会议也为世界进一步了解中国、了解杭州、了解萧山提供了极好的机遇和平台，提升了杭州和萧山的城市地位和影响力，增加了杭州和萧山在未来国际投资中的吸引力，从而加速了杭州（萧山）的国际化进程。萧山全民参与G20服务保障工作的主人翁精神、无私奉献精神以及爱国主义精神铸就了G20峰会服务精神，成为了萧山人民的又一精神财富。',
          video: 'http://v.cztvcloud.com/video/xhw/vod/2018/12/24/48f909509a2b47b7a89f04003841b62c/48f909509a2b47b7a89f04003841b62c_h264_800k_mp4.mp4',
          poster: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/ten/9.jpg'
        },
        {
          title: '10、萧山进入亚运时间',
          content: '2015年9月16日，亚奥理事会宣布杭州获得2022年亚运会主办权。2018年2月12日，杭州亚组委正式公布2022年亚运会亚运村选址萧山钱江世纪城。规划中的亚运村核心区总面积113公顷，由运动员村、技术官员村、媒体村组成，可容纳1万余名运动员和随队官员、5000名媒体人员、4000名裁判员，并提供星级服务。亚运村计划于2021年底竣工，2022年3月全面投入试运行。与此同时，亚运会主场馆、游泳馆、区体育中心足球、举重馆以及瓜沥、临浦等体育馆建设全面开工。亚运会在萧山举办将使萧山在城市建设、经济发展、社会民生等领域得到前所未有的发展，城市的经济实力、自然和人文环境、知名度和影响力都将得到大幅度提升。',
          video: 'http://v.cztvcloud.com/video/xhw/vod/2018/12/24/52213c041d2d477eb270f6e94401d2a2/52213c041d2d477eb270f6e94401d2a2_h264_800k_mp4.mp4',
          poster: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/ten/10.jpg'
        }
      ]
    }
  },
  methods: {
    goBack () {
      this.$router.push({
        path: '/selector'
      })
    },
    scrollTo (e) {
      this.$refs.container.style.backgroundPositionX = (e.target.scrollTop / this.delta * 100) + '%'
    },
    toggleMusic () {
      this.$emit('music')
    },
    share () {
      if (window.PalauAPI) {
        window.PalauAPI.share('all', '我骄傲，我是萧山人，勇立潮头，萧山改革开放40年全景图', '40年了，这些大事发生在萧然大地上，影响了你我，今天我们一起回顾，也一起展望未来。',
          location.href, 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/regoShare.png')
      }
    },
    videoPlay () {
      this.$emit('music', 'videoPlay')
    },
    videoPause () {
      this.$emit('music', 'videoPause')
    }
  },
  mounted () {
    // this.$refs.allVideo.onplay = () => {
    //   this.$emit('music', 'videoPlay')
    // }
    // this.$refs.allVideo.onpause = () => {
    // }
    // if (window.wx) {
    //   window.wx.onMenuShareTimeline({
    //     title: '勇立潮头，萧山改革开放40年全景图',
    //     link: location.href.split('#')[0],
    //     imgUrl: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/regoShare.png',
    //     success: function () {
    //     }
    //   })
    //   window.wx.onMenuShareAppMessage({
    //     title: '勇立潮头，萧山改革开放40年全景图',
    //     desc: '40年了，这些大事发生在萧然大地上，影响了你我，今天我们一起回顾，也一起展望未来。',
    //     link: location.href.split('#')[0],
    //     imgUrl: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/regoShare.png',
    //     type: '',
    //     dataUrl: '',
    //     success: function () {
    //     }
    //   })
    // }
  },
  destroyed () {
    this.$emit('music', 'videoPause')
  },
  computed: {
    delta () {
      return this.$refs.container.scrollHeight - this.$refs.container.clientHeight
    },
    canShare () {
      return window.canShare
    }
  }
}
</script>

<style lang="stylus" scoped>
.bigbang
  .container
    height 100%
    background url('https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/all1.png')no-repeat 0% 100%
    background-size 120% auto
    animation swing 8s infinite linear
    overflow auto
    position relative
    header
      padding-top .8rem
      padding-left .8rem
      position relative
      text-align center
      .title
        width 60%
      .return
        position absolute
        left 0
        top 2rem
        width 1.8rem
    section
      padding .6rem .3rem .2rem
      flex 1
      display flex
      flex-direction column
      .content
        line-height 1.5
        flex 1
        background rgba(255,255,255,.8)
        margin-top .4rem
        border 2px solid #000
        padding .4rem
        overflow hidden
        transition .3s
        .text
          .item
            margin-bottom .6rem
          p
            margin-bottom .2rem
          .title
            font-weight bold
            // &:first-letter
            font-size 1.4em
          .video
            height 0
            padding-top 56%
            position relative
            top 0
            left auto
            overflow hidden
            margin-bottom .2rem
            video
              position absolute
              width 100%
              height 100%
              top 0
              background #000
              object-fit cover
      .showall
        position absolute
        bottom .6rem
        left .3rem
        right .3rem
        top 0
      .logo
        text-align center
        line-height .6rem
        img
          width 3rem
          margin 0 .3rem
    .icons
      position absolute
      right .3rem
      top .3rem
      color #fff
      i
        font-size .44rem
        padding .12rem
        display inline-block
        box-sizing border-box
        border 1px solid #ffffff
        border-radius 50%
        background rgba(255,255,255,.4)
      .icon-music
        color #999
        position relative
        &:after
          content ''
          border-top 1px solid #fff
          position absolute
          width 100%
          top 50%
          left 0
          transform rotate(40deg)
      .shake
        animation rock 3s linear infinite
        color #000
        &:after
          display none
  .share
    position absolute
    top 1.8rem
    right 0
    border-radius .4rem 0 0 .4rem
    color #ffffff
    background #129ade
    font-size .32rem
    padding  .2rem .1rem .2rem .2rem
    text-align center
    box-shadow 2px 2px 5px #888
    .parti
      font-size 12px
      .iconfont
        font-size 14px
  .watched
    position absolute
    left .3rem
    top .4rem
    color #fff
@keyframes swing
  0%
    background-position 0% 100%
  50%
    background-position 100% 100%
  100%
    background-position 0% 100%
</style>
