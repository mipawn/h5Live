<template>
  <div class="photo">
    <transition enter-active-class="animated slideInDown" leave-active-class="animated slideOutUp">
      <div class="top" v-show="istop">
        <b><i class="iconfont icon-angle-double-up"></i></b>
        <span>下拉进入 — <span>改革大事记</span> </span>
      </div>
    </transition>
    <div class="container" ref="container" @scroll="scrollTo" @touchmove="toNext" @touchstart="addEvent">
      <header>
        <img :src="'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/region/' + region + '.png'" alt="" class="region"><br>
        <img src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/phototitle1.png" alt="" class="title"><br>
        <img class="return" src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/return.png" @click="goBack" alt="">
      </header>
      <section>
        <dl v-for="(item, index) of imgs" :key="index" @click="handleImgClick(index)">
          <dd><img :src="item" alt=""></dd>
          <!-- <dt>示例图片</dt> -->
        </dl>
      </section>
    </div>
    <transition enter-active-class="animated slideInUp" leave-active-class="animated slideOutDown">
      <div class="btm" v-show="isbottom">
        <b><i class="iconfont icon-angle-double-up"></i></b>
        <span>上滑进入 —
          <span v-if="movieShow">影像{{region}}</span>
          <span v-if="!movieShow">{{region}}全景图</span>
        </span>
      </div>
    </transition>
    <gallery :imgs="imgs" :init="init" v-if="showGallery" @close="showGallery = false" ></gallery>
</div>
</template>

<script>
import gallery from './gallery'
export default {
  name: 'photo',
  components: {gallery},
  data () {
    return {
      isbottom: false,
      istop: true,
      next: false,
      screenY: 0,
      scrollTop: 0,
      region: '进化',
      imgs: [],
      init: 0,
      showGallery: false,
      id: '',
      movieShow: true
    }
  },
  methods: {
    goBack () {
      this.$router.push({
        path: '/selector'
      })
    },
    scrollTo (e) {
      this.scrollTop = e.target.scrollTop
      this.isbottom = this.scrollTop === this.delta
      this.istop = this.scrollTop === 0
    },
    toNext (e) {
      if (!this.screenY) return
      if (this.isbottom && this.screenY && (e.targetTouches[0].screenY < this.screenY - 60)) {
        this.$router.replace({
          path: this.movieShow ? 'movie' : 'detail',
          query: {
            id: this.$route.query.id,
            dir: 1,
            region: this.$route.query.region
          }
        })
      }
      if (this.istop && this.screenY && (e.targetTouches[0].screenY > this.screenY)) {
        e.preventDefault()
        if (e.targetTouches[0].screenY > this.screenY + 60) {
          this.$router.replace({
            path: 'bigbang',
            query: {
              id: this.$route.query.id,
              dir: 0,
              region: this.$route.query.region
            }
          })
        }
      }
    },
    addEvent (e) {
      if (this.isbottom || this.istop) {
        this.screenY = e.targetTouches[0].screenY
      } else {
        this.screenY = 0
      }
    },
    handleImgClick (i) {
      this.init = i
      this.showGallery = true
    }
  },
  created () {
    this.region = this.$route.query.region
    this.imgs = window.streetInfo.img_url
    this.id = +this.$route.query.id
    this.movieShow = !(this.id === 1 || this.id === 4 || this.id === 6 || this.id === 8 || this.id === 9)
  },
  mounted () {
    this.isbottom = this.scrollTop === this.delta
  },
  computed: {
    delta () {
      return this.$refs.container.scrollHeight - this.$refs.container.clientHeight
    }
  }
}
</script>

<style lang="stylus" scoped>
.photo
  .container
    height 100%
    background url('https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/photo1.png')repeat center 0%
    background-size 120%
    animation swing 16s infinite linear
    overflow auto
    header
      padding-top 1rem
      padding-left .8rem
      position relative
      text-align center
      .title
        height 1.1rem
        padding-left 1rem
      .region
        max-height 1.2rem
        max-width 55%
        padding-right 1.6rem
      .return
        position absolute
        left 0
        top 2rem
        width 1.8rem
    section
      padding .6rem .3rem 1rem
      overflow auto
      dl
        float left
        width 49%
        box-sizing border-box
        background  linear-gradient(to top, #8de, #fff)
        padding .1rem
        border 1px solid #444
        margin-bottom .4rem
        &:nth-child(2n+1)
          margin-right 2%
        dd
          background url('~https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/pre.jpg')
          background-size 100% 100%
          padding-top 75%
          position relative
          img
            position absolute
            top 0
            left 0
            width 100%
            height 100%
        dt
          text-align center
          font-size .28rem
          margin-top .2rem
          overflow hidden
          white-space nowrap
          text-overflow ellipsis
  .top, .btm
    position fixed
    top 0
    left 0
    right 0
    color #fff
    line-height 3
    text-align center
    animation-duration .3s
    z-index 2
    background linear-gradient(to top, transparent, rgba(0, 0, 0, .5))
    i
      display inline-block
      animation pop 1s infinite cubic-bezier(.25,.0,.75,1)
  .btm
    background linear-gradient(to bottom, transparent, rgba(0, 0, 0, .5))
    top auto
    bottom 0
    b
      display inline-block
      transform rotateZ(180deg)
@keyframes pop
  0%
    transform translateY(-5px)
  50%
    transform translateY(5px)
  100%
    transform translateY(-5px)
@keyframes swing
  0%
    background-position 50% 0%
  50%
    background-position 50% 100%
  100%
    background-position 50% 0%
</style>
