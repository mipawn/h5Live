<template>
  <div class="bigbang">
    <transition enter-active-class="animated slideInDown" leave-active-class="animated slideOutUp">
      <div class="top" v-show="istop">
        <b><i class="iconfont icon-angle-double-up"></i></b>
        <span>下拉进入 — <span>{{region}}全景图</span> </span>
      </div>
    </transition>
    <div class="container" ref="container" @scroll="scrollTo" @touchmove="toNext" @touchstart="addEvent">
      <header>
        <img :src="'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/region/'+ region +'.png'" alt="" class="region"><br>
        <img src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/bigbang1.png" alt="" class="title"><br>
        <img class="return" src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/return.png" @click="goBack" alt="">
      </header>
      <section>
        <div class="content">
          <div class="text">
            <p v-for="(item, index) of content" :key="index" v-html="item">
            </p>
          </div>
        </div>
      </section>
    </div>
    <transition enter-active-class="animated slideInUp" leave-active-class="animated slideOutDown">
      <div class="btm" v-show="isbottom">
        <b><i class="iconfont icon-angle-double-up"></i></b>
        <span>上滑进入 — <span>{{photoShow ? '图说改革' : '影像' + region}}</span> </span>
      </div>
    </transition>
  </div>
</template>

<script>
export default {
  name: 'bigbang',
  data () {
    return {
      isbottom: false,
      istop: true,
      next: false,
      screenY: 0,
      scrollTop: 0,
      region: '进化',
      content: [],
      photoShow: true
    }
  },
  methods: {
    goBack () {
      this.$router.push({
        path: '/selector'
      })
    },
    scrollTo (e) {
      this.scrollTop = e.target.scrollTop
      this.isbottom = this.scrollTop === this.delta
      this.istop = this.scrollTop === 0
    },
    toNext (e) {
      if (!this.screenY) return
      if (this.isbottom && this.screenY && (e.targetTouches[0].screenY < this.screenY - 60)) {
        this.$router.replace({
          path: this.photoShow ? 'photo' : 'movie',
          query: {
            id: this.$route.query.id,
            dir: 1,
            region: this.$route.query.region
          }
        })
      }
      if (this.istop && this.screenY && (e.targetTouches[0].screenY > this.screenY)) {
        e.preventDefault()
        if (e.targetTouches[0].screenY > this.screenY + 60) {
          this.$router.replace({
            path: 'detail',
            query: {
              id: this.$route.query.id,
              dir: 0,
              region: this.$route.query.region
            }
          })
        }
      }
    },
    addEvent (e) {
      if (this.isbottom || this.istop) {
        this.screenY = e.targetTouches[0].screenY
      } else {
        this.screenY = 0
      }
    }
  },
  created () {
    this.region = this.$route.query.region
    if (window.streetInfo.content) {
      this.content = window.streetInfo.content.split('|')
    }
  },
  mounted () {
    this.isbottom = this.scrollTop === this.delta
    this.photoShow = !(+this.$route.query.id === 2)
    console.log(this.photoShow)
  },
  computed: {
    delta () {
      return this.$refs.container.scrollHeight - this.$refs.container.clientHeight
    }
  }
}
</script>

<style lang="stylus" scoped>
.bigbang
  overflow hidden
  .container
    // min-height 170vw
    height 100%
    background url('https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/bigbangbg1.png')no-repeat 0% 0%
    background-size 120% 100%
    animation swing 8s infinite linear
    overflow auto
    header
      padding-top 1rem
      padding-left .8rem
      position relative
      text-align center
      .region
        max-height 1.2rem
        max-width 55%
        padding-right 1.2rem
      .title
        height 1rem
      .return
        position absolute
        left 0
        top 1.6rem
        width 1.8rem
    section
      padding .6rem .3rem 1rem
      overflow hidden
      .center
        text-align center
        img
          width 80%
      .content
        line-height 1.5
        height 100%
        // background linear-gradient(to top, #8de, #fff)
        background rgba(255,255,255,.9)
        border 2px solid #000
        padding 0 .4rem
        overflow auto
        .text
          padding-top .4rem
          counter-reset param
          p
            margin-bottom .2rem
            // &:first-line
            //   font-weight bold
            &:before
              counter-increment param
              content counter(param)'.'
              font-weight bold
              font-size 1.6em
              margin-right .4em
  .top, .btm
    position fixed
    top 0
    left 0
    right 0
    color #fff
    line-height 3
    text-align center
    animation-duration .3s
    z-index 2
    background linear-gradient(to top, transparent, rgba(255,255,255,.5))
    i
      display inline-block
      animation pop 1s infinite cubic-bezier(.25,.0,.75,1)
  .btm
    background linear-gradient(to bottom, transparent, rgba(0,0,0,.5))
    top auto
    bottom 0
    b
      display inline-block
      transform rotateZ(180deg)
@keyframes pop
  0%
    transform translateY(-5px)
  50%
    transform translateY(5px)
  100%
    transform translateY(-5px)
@keyframes swing
  0%
    background-position 0% 0%
  50%
    background-position 100% 0%
  100%
    background-position 0% 0%
</style>
