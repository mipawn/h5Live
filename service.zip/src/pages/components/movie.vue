<template>
  <div class="movie">
    <transition enter-active-class="animated slideInDown" leave-active-class="animated slideOutUp">
      <div class="top" v-show="istop">
        <b><i class="iconfont icon-angle-double-up"></i></b>
        <span>下拉进入 — <span>{{photoShow ? '图说改革' : '改革大事记'}}</span> </span>
      </div>
    </transition>
    <div class="container" @scroll="scrollTo" @touchmove="toNext" @touchstart="addEvent">
      <header>
        <transition enter-active-class="animated fadeIn" leave-active-class="animated fadeOut">
          <img v-show="toggle" src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/moviebg1.png" alt="" class="bg" width="70%">
        </transition>
        <transition enter-active-class="animated fadeIn" leave-active-class="animated fadeOut">
          <img v-show="!toggle" src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/moviebg2.png" alt="" class="bg" width="70%">
        </transition>
        <img src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/movie.png" alt="" class="title"><br>
        <img :src="'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/region/' + region + '.png'" alt="" class="region"><br>
        <img class="return" src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/return.png" @click="goBack" alt="">
      </header>
      <section>
        <div class="video">
          <video :src="movie" controls ref="movie" loop
            :poster="'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/video/' + id + '.jpg'"></video>
        </div>
        <img src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/window.png" alt="" class="foot">
      </section>
    </div>
    <transition enter-active-class="animated slideInUp" leave-active-class="animated slideOutDown">
      <div class="btm" v-show="isbottom">
        <b><i class="iconfont icon-angle-double-up"></i></b>
        <span>上滑进入 — <span>全景图</span> </span>
      </div>
    </transition>
  </div>
</template>

<script>
export default {
  name: 'movie',
  data () {
    return {
      isbottom: true,
      istop: true,
      next: false,
      screenY: 0,
      scrollTop: 0,
      toggle: true,
      region: '进化',
      movie: '',
      id: '',
      photoShow: true
    }
  },
  methods: {
    goBack () {
      this.$router.push({
        path: '/selector'
      })
    },
    scrollTo (e) {
      this.$refs.container.style.backgroundPositionY = (e.target.scrollTop / this.delta * 100) + '%'
      // this.$refs.container.style.backgroundPositionX = (e.target.scrollTop / this.delta * 100) + '%'
      this.scrollTop = e.target.scrollTop
      this.isbottom = this.scrollTop === this.delta
      this.istop = this.scrollTop === 0
    },
    toNext (e) {
      if (!this.screenY) return
      if (this.isbottom && this.screenY && (e.targetTouches[0].screenY < this.screenY - 60)) {
        this.$router.replace({
          path: 'detail',
          query: {
            id: this.$route.query.id,
            dir: 1,
            region: this.$route.query.region
          }
        })
      }
      if (this.istop && this.screenY && (e.targetTouches[0].screenY > this.screenY)) {
        e.preventDefault()
        if (e.targetTouches[0].screenY > this.screenY + 60) {
          this.$router.replace({
            path: this.photoShow ? 'photo' : 'bigbang',
            query: {
              id: this.$route.query.id,
              dir: 0,
              region: this.$route.query.region
            }
          })
        }
      }
    },
    addEvent (e) {
      if (this.isbottom || this.istop) {
        this.screenY = e.targetTouches[0].screenY
      } else {
        this.screenY = 0
      }
    }
  },
  created () {
    this.region = this.$route.query.region
  },
  mounted () {
    setInterval(() => {
      this.toggle = !this.toggle
    }, 3000)
    this.id = this.$route.query.id
    this.photoShow = !(+this.$route.query.id === 2)
    this.movie = window.streetInfo.video_url || 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/bg.mp4'
    this.$refs.movie.onplay = () => {
      this.$emit('music', 'videoPlay')
    }
    this.$refs.movie.onpause = () => {
      this.$emit('music', 'videoPause')
    }
  },
  destroyed () {
    this.$emit('music', 'videoPause')
  },
  computed: {
    delta () {
      return this.$refs.container.scrollHeight - this.$refs.container.clientHeight
    }
  }
}
</script>

<style lang="stylus" scoped>
.movie
  overflow auto
  .container
    height 100%
    display flex
    flex-direction column
    overflow auto
    // background url('~https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/detail/moviebg.png')no-repeat right top
    // background-size 70%
    header
      padding-top 1rem
      padding-left .8rem
      position relative
      text-align center
      .bg
        position absolute
        right 0
        top 0
        z-index -1
      .region
        max-height 1.2rem
        padding-left 1.6rem
      .title
        height 1.2rem
        padding-right 1.8rem
      .return
        position absolute
        left 0
        top 1.6rem
        width 1.8rem
    section
      padding .6rem .4rem
      flex 1
      display flex
      flex-direction column
      justify-content space-around
      .video
        padding-top 56%
        position relative
        overflow hidden
        video
          width 100%
          height 100%
          position absolute
          top 0
          left 0
          background #000
          object-fit cover
      .foot
        width 80%
        margin .6rem auto
  .top, .btm
    position fixed
    top 0
    left 0
    right 0
    color #fff
    line-height 3
    text-align center
    animation-duration .3s
    z-index 2
    background linear-gradient(to top, transparent, rgba(255, 255, 255, .5))
    i
      display inline-block
      animation pop 1s infinite cubic-bezier(.25,.0,.75,1)
  .btm
    background linear-gradient(to bottom, transparent, rgba(255, 255, 255, .5))
    top auto
    bottom 0
    b
      display inline-block
      transform rotateZ(180deg)
@keyframes pop
  0%
    transform translateY(-5px)
  50%
    transform translateY(5px)
  100%
    transform translateY(-5px)
</style>
