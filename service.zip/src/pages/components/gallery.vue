<template>
  <div class="gallery" @click="handleGalleryClick" >
    <div class="wrapper">
      <swiper :options="swiperOption" ref="newSwiper">
        <swiper-slide v-for="item in imgs" :key="item" class="sliders">
          <img class="gallery-img" :src="item" alt="" />
        </swiper-slide>
        <swiper-slide v-for="item in video" :key="item" class="sliders">
          <video class="gallery-video" :src="item" controls></video>
        </swiper-slide>
        <div class="swiper-pagination" slot="pagination"></div>
      </swiper>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Gallery',
  props: {
    imgs: Array,
    video: Array,
    init: Number
  },
  data () {
    return {
      swiperOption: {
        pagination: {
          el: '.swiper-pagination',
          type: 'fraction'
        },
        initialSlide: this.init
      }
    }
  },
  computed: {
    swiper () {
      return this.$refs.newSwiper.swiper
    }
  },
  methods: {
    handleGalleryClick () {
      this.$emit('close', this.$el)
    }
  },
  mounted () {
    // this.swiper.slideTo(1, 1000, false)
  }
}
</script>

<style lang="stylus" scoped>
  .gallery
    position: fixed
    top 0
    right 0
    bottom 0
    left 0
    background rgba(0, 0, 0, .7)
    z-index 99
    .wrapper
      width 100%
      height 100%
      .gallery-video,.gallery-img
        width 100%
        max-height 100%
      .swiper-pagination
        color #fff
        bottom 1.6rem
      .sliders
        height 100vh
        line-height 100vh
</style>
