<template>
  <div class="home">
    <header>
      <transition name="punch">
        <img class="ani1" v-show="show1" src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/home/1-1.png" alt="">
      </transition>
      <transition name="punch">
        <img class="ani2" v-show="show2" src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/home/2-2.png" alt="">
      </transition>
      <transition name="punch">
        <img class="ani3" v-show="show3" src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/home/3-3.png" alt="">
      </transition>
      <transition
        enter-active-class="animated flip"
        leave-active-class="animated fadeOut">
        <img class="ani4" v-show="show4" src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/home/4-4.png" alt="">
      </transition>
    </header>
    <section>
      <img src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/home/homeMap-1.png" alt="">
    </section>
    <footer v-if="start">
      <img src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/home/homeFooter.png" alt="" class="btmImg">
    </footer>
    <transition
      enter-active-class="animated fadeIn"
      leave-active-class="animated fadeOut">
      <div class="start" v-show="!start">
        <transition
          enter-active-class="animated fadeIn"
          leave-active-class="animated fadeOut">
          <img v-show="showPub" src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/home/homeFooter.png" alt="" class="pub">
        </transition>
      </div>
    </transition>
    <transition
      enter-active-class="animated fadeIn"
      leave-active-class="animated fadeOut">
      <div class="swiper" v-show="swiperShow">
        <div class="trans">
          <img :src="item" alt="" v-for="(item, index) of adText" :key="index">
        </div>
      </div>
    </transition>
    <link rel="stylesheet" href="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/map.png">
  </div>
</template>

<script>
export default {
  name: 'home',
  data () {
    return {
      show1: false,
      show2: false,
      show3: false,
      show4: false,
      start: false,
      showPub: false,
      swiperOption1: {
        loop: false,
        autoplay: true
      },
      swiperOption2: {
        loop: false,
        autoplay: {
          reverseDirection: true
        }
      },
      adText: [
        'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/image/1.png',
        'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/image/2.png',
        'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/image/3.png',
        'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/image/4.png',
        'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/image/5.png',
        'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/image/6.png',
        'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/image/7.png',
        'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/image/8.png',
        'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/image/9.png',
        'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/image/10.png'
      ],
      textShow: 0,
      textHide: 0,
      swiperShow: false
    }
  },
  methods: {
    toSelector () {
      this.showSelector = true
      this.$router.push({
        path: 'selector'
      })
    },
    startAnimation () {
      setTimeout(() => {
        this.show1 = true
      }, 400)
      setTimeout(() => {
        this.show2 = true
      }, 800)
      setTimeout(() => {
        this.show3 = true
      }, 1200)
      setTimeout(() => {
        this.show4 = true
      }, 2000)
      setTimeout(() => {
        this.swiperShow = true
        // this.toSelector()
        this.text()
      }, 3000)
    },
    open () {
      this.showPub = true
      setTimeout(() => {
        this.showPub = false
        setTimeout(() => {
          this.start = true
          this.startAnimation()
        }, 1000)
      }, 1500)
    },
    text () {
      this.textShow++
      let dt = setInterval(() => {
        if (this.textShow === 13) {
          clearInterval(dt)
          this.textShow = 0
          this.swiperShow = false
          setTimeout(() => {
            this.toSelector()
          }, 1000)
        }
        this.textShow++
      }, 1000)
    }
  },
  mounted () {
    if (window.start) {
      this.start = true
      this.startAnimation()
    } else {
      this.open()
      window.start = true
    }
  },
  computed: {
    swiper1 () {
      return this.$refs.mySwiper1.swiper
    },
    swiper2 () {
      return this.$refs.mySwiper2.swiper
    }
  }
}
</script>

<style lang="stylus" scoped>
.punch-enter
  transform scale(4)
  opacity 0
.punch-leave-active
  transform scale(1)
@keyframes trans
  0%
    transform translateY(0)
  100%
    transform translateY(-400%)
.home
  header
    position absolute
    top 0
    left 0
    width 100%
    text-align center
    padding-top 2rem
    img
      width 80%
      transition .3s
    .ani1
      width 60%
      margin-right 1.4rem
      margin-bottom .2rem
    .ani2
      width 70%
    .ani3
      width 40%
      margin-top .4rem
    .ani4
      width 12%
      position absolute
      top 1.6rem
      right 1.2rem
  section
    margin-top 4rem
    padding 0 1rem
    img
      width 100%
    p
      color #ffffff
      font-size .44rem
      text-align center
      position relative
      top -1.6rem
  footer
    height 1.4rem
    position absolute
    bottom 0
    left 0
    right 0
    text-align center
    img
      height .5rem
    p
      position fixed
      bottom .4rem
      right .4rem
      color #ffffff
  .swiper
    z-index 10
    position fixed
    top 0
    right 0
    bottom 0
    left 0
    background rgba(0,0,0,.6)
    background-size 100% 100%
    .trans
      width 100%
      position absolute
      top 100%
      height 16rem
      animation trans 20s linear
      animation-fill-mode forwards
      img
        max-width 100%
        object-fit cover
    .swiper-container
      height 50%
      .swiper-slide
        text-align center
        display flex
        align-items center
        justify-content center
        img
          width 60%
  .start
    position fixed
    top 0
    right 0
    bottom 0
    left 0
    background rgba(0,0,0,.8)
    .btn
      border 2px solid #ffffff
      background #0082de
      color #ffffff
      font-size .44rem
      border-radius .5rem
      padding 0 .4rem
      position absolute
      top 50%
      left 50%
      transform translate(-50%,-50%)
      line-height 1rem
    .pub
      width 70%
      position absolute
      top 50%
      left 50%
      transform translate(-50%,-50%)
</style>
