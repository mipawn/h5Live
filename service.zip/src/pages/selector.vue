<template>
  <div class="selector">
    <div class="container">
      <header>
        <transition
          enter-active-class="animated jackInTheBox"
          leave-active-class="animated fadeOut">
          <img v-show="show1" src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/secondTitle1.png" alt="">
        </transition>
      </header>
      <section @click="showSwiper = false">
        <transition
          enter-active-class="animated jackInTheBox"
          leave-active-class="animated fadeOut">
          <img v-show="show2" src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/map.png" alt="">
        </transition>
        <div class="small">
          <transition-group name="fade">
            <img v-for="item of list" :key="item.name" v-show="region === item.name && item.name !== '萧山区'"
              :src="item.src" alt="">
          </transition-group>
        </div>
        <transition
          enter-active-class="animated rotateIn"
          leave-active-class="animated fadeOut">
          <div class="rego" v-show="show4">
            <img src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/rego.png" alt="">
          </div>
        </transition>
      </section>
      <footer>
        <transition
          enter-active-class="animated jackInTheBox"
          leave-active-class="animated fadeOut">
          <div class="bar" v-show="show3">
            <div class="left" @click="toDetail('萧山区')">进入全区</div>
            <div class="center" @click="showSwiper = true"></div>
            <div class="right" @click="showSwiper = true">{{region || '选择镇街'}}</div>
          </div>
        </transition>
        <swiper :options="swiperOption" v-if="showSwiper" ref="mySwiper">
          <swiper-slide v-for="n in 11" :key="n">
            <p :data-id="list[2 * n - 2] ? list[2 * n - 2].id : ''">
              {{list[2 * n - 2] ? list[2 * n - 2].name : ''}}
            </p>
            <p :data-id="list[2 * n - 1] ? list[2 * n - 1].id : ''">
              {{list[2 * n - 1] ? list[2 * n - 1].name : ''}}
            </p>
          </swiper-slide>
        </swiper>
      </footer>
      <div class="logo">
        <img src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/home/homeFooter.png" alt="" class="btmImg">
      </div>
    </div>
    <div class="icons">
      <i :class="'iconfont icon-music' + (audioPlay ? ' shake' : '')" @click="toggleMusic"></i>
    </div>
    <div class="share" @click="share" v-if="canShare">
      <span>分享</span>
    </div>
    <div class="watched" >
      <span>阅读量</span>
      {{watched || ''}}
    </div>
  </div>
</template>

<script>
export default {
  name: 'selector',
  props: {
    audioPlay: Boolean,
    watched: Number
  },
  data () {
    return {
      list: [
        {
          id: '11',
          name: '楼塔镇',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/楼塔镇.png',
          path: '楼塔'
        },
        {
          id: '10',
          name: '河上镇',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/河上镇.png',
          path: '河上'
        },
        {
          id: '22',
          name: '戴村镇',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/戴村镇.png',
          path: '戴村'
        },
        {
          id: '9',
          name: '临浦镇',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/临浦镇.png',
          path: '临浦'
        },
        {
          id: '12',
          name: '浦阳镇',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/浦阳镇.png',
          path: '浦阳'
        },
        {
          id: '13',
          name: '进化镇',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/进化镇.png',
          path: '进化'
        },
        {
          id: '19',
          name: '所前镇',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/所前镇.png',
          path: '所前'
        },
        {
          id: '21',
          name: '义桥镇',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/义桥镇.png',
          path: '义桥'
        },
        {
          id: '20',
          name: '衙前镇',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/衙前镇.png',
          path: '衙前'
        },
        {
          id: '14',
          name: '瓜沥镇',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/瓜沥镇.png',
          path: '瓜沥'
        },
        {
          id: '16',
          name: '益农镇',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/益农镇.png',
          path: '益农'
        },
        {
          id: '15',
          name: '党湾镇',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/党湾镇.png',
          path: '党湾'
        },
        {
          id: '1',
          name: '城厢街道',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/城厢街道.png',
          path: '城厢'
        },
        {
          id: '2',
          name: '北干街道',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/北干街道.png',
          path: '北干'
        },
        {
          id: '3',
          name: '蜀山街道',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/蜀山街道.png',
          path: '蜀山'
        },
        {
          id: '4',
          name: '新塘街道',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/新塘街道.png',
          path: '新塘'
        },
        {
          id: '8',
          name: '闻堰街道',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/闻堰镇.png',
          path: '闻堰'
        },
        {
          id: '18',
          name: '宁围街道',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/宁围镇.png',
          path: '宁围'
        },
        {
          id: '17',
          name: '新街街道',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/新街镇.png',
          path: '新街'
        },
        {
          id: '5',
          name: '靖江街道',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/靖江街道.png',
          path: '靖江'
        },
        {
          id: '6',
          name: '南阳街道',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/南阳街道.png',
          path: '南阳'
        },
        {
          id: '7',
          name: '红山农场',
          src: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/small/红山农场.png',
          path: '红山农场'
        }
      ],
      swiperOption: {
        height: 150,
        direction: 'vertical',
        slidesPerView: 3.5,
        loop: false,
        on: {
          click: function (e) {
            this.region = e.target.innerText
            let id = e.target.getAttribute('data-id')
            this.showSwiper = false
            setTimeout(() => {
              this.toDetail('', id)
            }, 1000)
          }.bind(this)
        }
      },
      region: '',
      showSwiper: false,
      show1: false,
      show2: false,
      show3: false,
      show4: false
    }
  },
  methods: {
    toDetail (region, id) {
      if (region) {
        this.$router.push({
          path: 'all',
          append: true
        })
      } else {
        this.$router.push({
          path: 'detail',
          append: true,
          query: {
            region: this.region.replace('镇', '').replace('街道', ''),
            id
          }
        })
      }
    },
    animating () {
      this.show1 = true
      setTimeout(() => {
        this.show2 = true
      }, 600)
      setTimeout(() => {
        this.show3 = true
      }, 1200)
      setTimeout(() => {
        this.show4 = true
      }, 1800)
    },
    toggleMusic () {
      this.$emit('music')
    },
    share () {
      if (window.PalauAPI) {
        window.PalauAPI.share('all', '我骄傲，我是萧山人，勇立潮头，萧山改革开放40年全景图', '40年了，这些大事发生在萧然大地上，影响了你我，今天我们一起回顾，也一起展望未来。',
          'https://h5.xianghunet.com/reform/index.html', 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/regoShare.png')
      }
    }
  },
  mounted () {
    // this.list.sort((a, b) => {
    //   return Math.random() > 0.5 ? -1 : 1
    // })
    this.animating()
    this.$emit('showShare')
    // window.shareTitle = '勇立潮头，萧山改革开放40年全景图'
    // window.shareLink = location.href.split('#')[0]
    // window.shareDesc = '40年了，这些大事发生在萧然大地上，影响了你我，今天我们一起回顾，也一起展望未来。'
    // if (window.wx) {
    //   window.wx.ready(() => {
    //     document.getElementById('music').play()
    //     window.wx.onMenuShareTimeline({
    //       title: '勇立潮头，萧山改革开放40年全景图',
    //       link: window.shareLink,
    //       imgUrl: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/regoShare.png',
    //       success: function () {
    //       }
    //     })
    //     window.wx.onMenuShareAppMessage({
    //       title: '勇立潮头，萧山改革开放40年全景图',
    //       desc: '40年了，这些大事发生在萧然大地上，影响了你我，今天我们一起回顾，也一起展望未来。',
    //       link: window.shareLink,
    //       imgUrl: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/regoShare.png',
    //       type: '',
    //       dataUrl: '',
    //       success: function () {
    //       }
    //     })
    //   })
    // }
  },
  computed: {
    swiper () {
      return this.$refs.mySwiper.swiper
    },
    canShare () {
      return window.canShare
    }
  }
}
</script>

<style lang="stylus" scoped>
.fade-enter-active, .fade-leave-active
  transition all .5s
.fade-leave-active
  transform translatey(-20px)
.fade-enter-active
  transform translatey(0)
.fade-enter
  opacity 0
  transform translatey(20px)
.fade-leave-to
  opacity 0
  transform translatey(-20px)
.selector
  overflow auto
  .container
    height 100%
    display flex
    flex-direction column
    header
      text-align center
      padding-top .6rem
      img
        width 80%
    section
      margin 0 .6rem
      flex 1
      position relative
      overflow hidden
      .small
        position absolute
        top 0
        left 0
        right 0
        bottom 0
        img
          position absolute
          top 0
          left 0
          right 0
          bottom 0
      img
        width 100%
        height 100%
        object-fit contain
      .rego
        position absolute
        bottom 0
        right 0
        width 2rem
        height 2rem
    footer
      text-align center
      height 3rem
      position relative
      .bar
        padding 0 .2rem
        display flex
        align-items center
        color #ffffff
        font-size .32rem
        height .8rem
        line-height .8rem
        position absolute
        top 1rem
        left .4rem
        right .4rem
        .left,.right
          flex 1
          border-radius 6px
          background: repeating-linear-gradient(to right, #0776c7, #13c3f4 50%, #0776c7 100%)
          box-shadow: -2px 2px 10px rgba(0, 0, 0, 0.34)
        .center
          font-size .44rem
          width 1rem
      .swiper-container
        background #468ad3
        color #ffffff
        font-size .32rem
        overflow hidden
        height:100%
        .swiper-slide
          display flex
          p
            flex 1
            display flex
            justify-content center
            align-items center
            height 100%
    .logo
      position fixed
      bottom .3rem
      left 0
      right 0
      text-align center
      img
        width 3rem
  .icons
    position absolute
    right .3rem
    top .3rem
    color #fff
    i
      font-size .44rem
      padding .12rem
      display inline-block
      box-sizing border-box
      border 1px solid #ffffff
      border-radius 50%
      background rgba(255,255,255,.4)
    .icon-music
      color #999
      position relative
      &:after
        content ''
        border-top 1px solid #fff
        position absolute
        width 100%
        top 50%
        left 0
        transform rotate(40deg)
    .shake
      animation rock 3s linear infinite
      color #000
      &:after
        display none
  .share
    position fixed
    top 2.8rem
    right 0
    border-radius .4rem 0 0 .4rem
    color #ffffff
    background #129ade
    font-size .32rem
    padding .2rem  .1rem .2rem .2rem
    text-align center
    box-shadow 2px 2px 5px #888
    .parti
      font-size 12px
      .iconfont
        font-size 14px
  .watched
    position fixed
    left .3rem
    top .3rem
    color #fff
</style>
