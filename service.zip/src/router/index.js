import Vue from 'vue'
import Router from 'vue-router'
import homepage from '@/pages/home'
const selector = () => import('@/pages/selector')
const detail = () => import('@/pages/detail')
const all = () => import('@/pages/components/all')
const bigbang = () => import('@/pages/components/bigbang')
const photo = () => import('@/pages/components/photo')
const movie = () => import('@/pages/components/movie')

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'home',
      component: homepage
    },
    {
      path: '/selector',
      component: selector
    },
    {
      path: '/selector/detail',
      component: detail
    },
    {
      path: '/selector/bigbang',
      component: bigbang
    },
    {
      path: '/selector/photo',
      component: photo
    },
    {
      path: '/selector/movie',
      component: movie
    },
    {
      path: '/selector/all',
      component: all
    }
  ]
})
