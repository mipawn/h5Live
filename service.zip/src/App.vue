<template>
  <div id="app">
    <keep-alive>
      <transition :name="animation">
        <router-view class="view" :watched="watched" :audioPlay="audioPlay" @music="toggleMusic"
          style="background-image:url('https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/bg.jpg')"></router-view>
      </transition>
    </keep-alive>
    <audio loop ref="music" id="music"
      src="https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/bg.mp3" ></audio>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'App',
  data () {
    return {
      animation: 'slide-left',
      audioPlay: true,
      videoPlay: false,
      watched: 0,
      region: '',
      first: true
    }
  },
  methods: {
    toggleMusic (sure) {
      if (sure === 'videoPlay') {
        this.videoPlay = true
        if (this.audioPlay) {
          this.$refs.music.pause()
        }
      } else if (sure === 'videoPause') {
        this.videoPlay = false
        if (this.audioPlay) {
          this.$refs.music.play()
        }
      } else {
        if (this.videoPlay) {
          return
        }
        if (this.audioPlay) {
          this.$refs.music.pause()
          this.audioPlay = false
        } else {
          this.$refs.music.play()
          this.audioPlay = true
        }
      }
    },
    getWatch () {
      let url = 'http://item.xianghunet.com/index/reform/click'
      axios.post(url).then(res => {
        if (typeof res.data.res === 'number') {
          this.watched = res.data.res
        }
      })
    },
    getConfig () {
      let url = 'http://h5.xianghunet.com/wx/wx_Signature.php'
      let formData = new FormData()
      if (this.$route.query.region) {
        formData.append('href', location.href)
      } else {
        formData.append('href', location.href.split('#')[0])
      }
      let conf = {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }
      axios.post(url, formData, conf).then(res => {
        res.data.jsApiList = ['checkJsApi', 'onMenuShareTimeline', 'onMenuShareAppMessage', 'updateAppMessageShareData', 'updateTimelineShareData']
        window.shareLink = res.data.url
        if (this.$route.query.region) {
          window.shareTitle = '我骄傲，我是' + this.$route.query.region + '人，勇立潮头，' + this.$route.query.region + '改革开放40年全景图'
        } else {
          window.shareTitle = '我骄傲，我是萧山人，勇立潮头，萧山改革开放40年全景图'
        }
        window.shareDesc = '40年了，这些大事发生在萧然大地上，影响了你我，今天我们一起回顾，也一起展望未来。'
        this.addListener()
        if (window.wx) {
          window.wx.config(res.data)
        }
      })
    },
    addListener () {
      if (window.wx) {
        window.wx.ready(() => {
          if (this.first) {
            document.getElementById('music').play()
          }
          this.first = false
          window.wx.onMenuShareTimeline({
            title: window.shareTitle,
            link: window.shareLink,
            imgUrl: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/rego.png',
            success: function () {
            }
          })
          window.wx.onMenuShareAppMessage({
            title: window.shareTitle,
            desc: window.shareDesc,
            link: window.shareLink,
            imgUrl: 'https://xsgbdstxinmeiti.oss-cn-beijing.aliyuncs.com/reform/imgs/second/rego.png',
            type: '',
            dataUrl: '',
            success: function () {
            }
          })
        })
      }
    }
  },
  mounted () {
    // alert(location.href)
    this.$refs.music.play()
    this.getConfig()
    this.addListener()
    this.getWatch()
    if (window.SZJSBridge) {
      window.canShare = true
    } else {
      window.canShare = false
    }
  },
  watch: {
    '$route' (to, from) {
      this.region = this.$route.query.region
      this.getConfig()
      if ((to.path === '/selector' && from.path === '/') ||
        (to.path === '/selector/detail' && from.path === '/selector')) {
        this.animation = 'fade-out'
        return
      }
      if (to.path.split('/').length === from.path.split('/').length) {
        if (to.query.dir) {
          this.animation = 'slide-top'
        } else {
          this.animation = 'slide-bottom'
        }
        return
      }
      if (to.path.length < from.path.length) {
        this.animation = 'slide-right'
      } else {
        this.animation = 'slide-left'
      }
    }
  }
}
</script>

<style lang="stylus">
.view
  position fixed
  top 0
  right 0
  bottom 0
  left 0
  background-size cover
  background-position top center
  background-repeat no-repeat
  transition .4s
.slide-left-enter
  transform translatex(100%)
.slide-left-leave-active
  transform scale(.8)
  opacity .6
.slide-right-enter
  opacity .6
.slide-right-leave-active
  transform translatex(100%)

.slide-top-enter
  transform translatey(100%)
.slide-top-leave-active
  transform translatey(-100%)
.slide-bottom-enter
  transform translatey(-100%)
.slide-bottom-leave-active
  transform translatey(100%)

.fade-out-enter
  opacity 0
.fade-out-leave-active
  transform scale(2)
  opacity 0
  transition-timing-function ease-in
.bgVideo
  position fixed
  top 0
  right 0
  bottom 0
  left 0
@keyframes rock
  0%
    transform rotate(30deg)
  50%
    transform rotate(-30deg)
  100%
    transform rotate(30deg)
#app
  overflow auto
</style>
